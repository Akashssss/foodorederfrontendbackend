document.addEventListener('DOMContentLoaded', () => {
    const productList = document.getElementById('product-list');
    const nextStepButton = document.getElementById('next-step-1');
    const prevStepButton = document.getElementById('prev-step-2');
    const placeOrderButton = document.getElementById('place-order');
    const customerIdInput = document.getElementById('customer-id');
    const step1 = document.getElementById('step-1');
    const step2 = document.getElementById('step-2');
    const productCounts = {};
    const url = 'https://localhost:7299/api/';

    async function fetchProducts() {
        try {
            const response = await axios.get(url + 'product');
            const products = response.data;

            // Initialize product counts
            products.forEach(product => {
                productCounts[product.productId] = 0;
            });

            // Update product list display
            updateProductList(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    }

    function updateProductList(products) {
        productList.innerHTML = '';

        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';

            const productName = document.createElement('div');
            productName.className = 'product-name';
            productName.textContent = `${product.name} - $${product.price}`;

            const productControls = document.createElement('div');
            productControls.className = 'product-controls';

            const decrementButton = document.createElement('button');
            decrementButton.textContent = '-';
            decrementButton.disabled = productCounts[product.productId] <= 0;
            decrementButton.addEventListener('click', () => {
                if (productCounts[product.productId] > 0) {
                    productCounts[product.productId]--;
                    updateProductList(products);
                    checkCartNotEmpty();
                }
            });

            const countSpan = document.createElement('span');
            countSpan.textContent = productCounts[product.productId];

            const incrementButton = document.createElement('button');
            incrementButton.textContent = '+';
            incrementButton.addEventListener('click', () => {
                productCounts[product.productId]++;
                updateProductList(products);
                checkCartNotEmpty();
            });

            productControls.append(decrementButton, countSpan, incrementButton);
            productDiv.append(productName, productControls);
            productList.appendChild(productDiv);
        });
    }

    function checkCartNotEmpty() {
        const hasItems = Object.values(productCounts).some(count => count > 0);
        nextStepButton.disabled = !hasItems;
    }

    function goToStep(stepNumber) {
        if (stepNumber === 1) {
            step1.classList.add('active');
            step2.classList.remove('active');
        } else if (stepNumber === 2) {
            step1.classList.remove('active');
            step2.classList.add('active');
        }
    }

    function createCart() {
        return Object.keys(productCounts)
            .filter(productId => productCounts[productId] > 0)
            .map(productId => ({
                productId: parseInt(productId, 10),
                quantity: productCounts[productId]
            }));
    }

    function clearForm() {
        customerIdInput.value = '';
        Object.keys(productCounts).forEach(productId => {
            productCounts[productId] = 0;
        });
        fetchProducts();
        checkCartNotEmpty();
    }

    nextStepButton.addEventListener('click', () => {
        goToStep(2);
    });

    prevStepButton.addEventListener('click', () => {
        goToStep(1);
    });

    placeOrderButton.addEventListener('click', async () => {
        const customerId = customerIdInput.value.trim();
        if (customerId) {
            const cart = createCart();
            const formData = {
                customerId: customerId,
                products: cart
            };

            try {
                const response = await axios.post(url + 'order', formData);
                alert('Order Response: ' + JSON.stringify(response.data));
                clearForm();
                window.location.href = 'view-orders.html';  // Redirect to view orders page
            } catch (error) {
                console.error('Error placing order:', error);
                alert('Error placing order. Please try again.');
            }
        } else {
            alert('Please enter a customer ID.');
        }
    });

    // Fetch and display products
    fetchProducts();
});
