


const url = 'https://localhost:7299/api/'



// const getCustomer = async function getCustomer() {
// const response  = await axios.get(url + 'customer')
// console.log(response.data)  ;

// }

// getCustomer() ; 








document.addEventListener('DOMContentLoaded', () => {
  const productList = document.getElementById('product-list');
  const createCartButton = document.getElementById('create-cart-button');
  const productCounts = {};

  // Function to fetch products from the API
  async function fetchProducts() {
    try {
      const response = await axios.get(url+ 'product');
      const products = response.data;

      // Initialize product counts
      products.forEach(product => {
        productCounts[product.productId] = 0;
      });

      // Update product list display
      updateProductList(products);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }

  function updateProductList(products) {
    productList.innerHTML = '';

    products.forEach(product => {
      const productDiv = document.createElement('div');
      productDiv.className = 'product';

      const productName = document.createElement('div');
      productName.className = 'product-name';
      productName.textContent = `${product.name} - $${product.price}`;

      const productControls = document.createElement('div');
      productControls.className = 'product-controls';

      const decrementButton = document.createElement('button');
      decrementButton.textContent = '-';
      decrementButton.disabled = productCounts[product.productId] <= 0;
      decrementButton.addEventListener('click', () => {
        if (productCounts[product.productId] > 0) {
          productCounts[product.productId]--;
          updateProductList(products);
        }
      });

      const countSpan = document.createElement('span');
      countSpan.textContent = productCounts[product.productId];

      const incrementButton = document.createElement('button');
      incrementButton.textContent = '+';
      incrementButton.addEventListener('click', () => {
        productCounts[product.productId]++;
        updateProductList(products);
      });

      productControls.append(decrementButton, countSpan, incrementButton);
      productDiv.append(productName, productControls);
      productList.appendChild(productDiv);
    });
  }

  function createCart() {
    const cart = Object.keys(productCounts)
      .filter(productId => productCounts[productId] > 0)
      .map(productId => ({
        productid: parseInt(productId, 10),
        quantity: productCounts[productId]
      }));

    // Print the cart to the console
    console.log('Cart:', cart);
  }

  createCartButton.addEventListener('click', createCart);

  // Fetch and display products
  fetchProducts();
});
