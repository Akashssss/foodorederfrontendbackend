﻿namespace Food_Order.Model
{
    public class CreateOrderDto
    {
        public int CustomerId { get; set; }
        public List<OrderProductDto> Products { get; set; }
    }
}
